Un module pour commuter une alimentation sur le rail positif.

<!-- AUTEUR : Nicolas LE GUERROUE -->
<!-- DATE : 2024 -->