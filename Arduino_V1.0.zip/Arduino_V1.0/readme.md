Un carte Arduino fait-maison, avec l'essentiel pour son bon fonctionnement.
Cette version n'intègre pas de régulateur de tension.
