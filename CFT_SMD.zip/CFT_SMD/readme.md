Un convertisseur Fréquence-Tension pour le Tracker solaire.
Son application vise à connaître la vitesse du vent en fonction de la fréquence d'un anémomètre.
<!-- AUTEUR : Nicolas LE GUERROUE -->
<!-- DATE : 2024 -->